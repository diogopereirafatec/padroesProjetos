package com.example.padroesprojetos.Model;

import java.util.Date;
import java.util.LinkedList;

public class Promocao {
    private String promo;
    private double valor;
    private Date ini_promo;
    private Date fim_promo;
    private LinkedList<Promocao> listaPromocoes;

    public Promocao(){};

    public Promocao (String promo, double valor, Date ini_promo, Date fim_promo){
        this.promo = promo;
        this.valor = valor;
        this.ini_promo = ini_promo;
        this.fim_promo = fim_promo;
    }

    public void AdicionaPromocao(Promocao promo){
        listaPromocoes = new LinkedList<Promocao>();
        listaPromocoes.add(promo);
    }
    public void AdicionaPromocao(){
        listaPromocoes = new LinkedList<Promocao>();
        Promocao promo1 = new Promocao("Escova de Chocolate", 75.00,new Date(2019,04,01),new Date(2019,04,30));
        Promocao promo2 = new Promocao("Trança Espinha de Peixe", 35.00,new Date(2019,04,01),new Date(2019,04,30));
        Promocao promo3 = new Promocao("Hidratação e Cauterização", 93.00,new Date(2019,04,01),new Date(2019,04,30));
        Promocao promo4 = new Promocao("Esmaltação em Gel", 30.00,new Date(2019,04,01),new Date(2019,04,30));
        Promocao promo5 = new Promocao("Alongamento de Cílios Fio a Fio", 48.00,new Date(2019,04,01),new Date(2019,04,30));
        Promocao promo6 = new Promocao("Depilação meia perna", 15.00,new Date(2019,04,01),new Date(2019,04,30));
        listaPromocoes.add(promo1);
        listaPromocoes.add(promo2);
        listaPromocoes.add(promo3);
        listaPromocoes.add(promo4);
        listaPromocoes.add(promo5);
        listaPromocoes.add(promo6);
    }

    public String getPromo() {
        return promo;
    }
    public double getValor(){
        return valor;
    }

    public LinkedList<Promocao> ListarPromocao(){
        AdicionaPromocao();
        return listaPromocoes;
    }

}
