package com.example.padroesprojetos.Model;

import java.util.List;

public class Cabelo {
    private String servico;
    private float valor;
    private List<Cabelo> ListaServico;

    private Cabelo(){};

    private Cabelo(String servico, float valor){
        this.servico = servico;
        this.valor = valor;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getServico() {
        return servico;
    }

    public void ListaServicos(Cabelo cabelo){
        ListaServico.add(cabelo);
    }

    public List<Cabelo>ListasServicos(){
        return ListaServico;
    }
}
