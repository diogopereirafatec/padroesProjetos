package com.example.padroesprojetos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private Button btn_cabelo;
    private Button btn_promocao;
    private Button btn_noiva;
    private Button btn_servico;
   // private Button btn_maquiagem;
   // private Button btn_massagem;
   // private Button btn_manicure;
   // private Button btn_pedicure;
    private ImageView imgLogo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_promocao = findViewById(R.id.btn_promocao);
        btn_servico = findViewById(R.id.btn_servico);
        //btn_noiva = findViewById(R.id.btn_noiva);
 //       btn_cabelo = findViewById(R.id.btn_cabelo);
  //      btn_maquiagem = findViewById(R.id.btn_maquiagem);
  //      btn_massagem = findViewById(R.id.btn_depilacao);
  //      btn_manicure = findViewById(R.id.btn_manicure);
  //      btn_pedicure = findViewById(R.id.btn_pedicure);
        imgLogo = findViewById(R.id.img_logo);

        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });

        btn_promocao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerPromocao.class));
            }
        });
        btn_servico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerServico.class));
            }
        });
       /* btn_noiva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerNoiva.class));
            }
        });
        btn_cabelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerCabelo.class));
            }
        });
        btn_maquiagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerMaquiagem.class));
            }
        });
        btn_massagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerMassagem.class));
            }
        });
        btn_manicure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerManicure.class));
            }
        });
        btn_pedicure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ControllerPedicure.class));
            }
        });*/
    }
}
