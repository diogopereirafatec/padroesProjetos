package com.example.padroesprojetos.Model;

public class Manicure {
}
