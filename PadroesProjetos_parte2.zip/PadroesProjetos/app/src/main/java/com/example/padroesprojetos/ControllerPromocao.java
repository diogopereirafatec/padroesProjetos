package com.example.padroesprojetos;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.padroesprojetos.Model.Promocao;

import java.util.LinkedList;


public class ControllerPromocao extends AppCompatActivity {

    private Button agendar;
    //private  Button btn_busca_cabelo;
    private LinkedList<Promocao> listaPromocoes;

    private ArrayAdapter<String> adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promocao);
        agendar = (Button) findViewById(R.id.btn_agenda_servico);
        ListView AllPromo = (ListView)findViewById(R.id.listaPromocoes);
        AdicionaPromocao();
        ArrayAdapter<Promocao> adapter = new ArrayAdapter<Promocao>(this,android.R.layout.simple_list_item_1,listaPromocoes);
        AllPromo.setAdapter(adapter);

        agendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ControllerPromocao.this, ControllerAgenda.class));
            }
        });

       /* btn_busca_cabelo = findViewById(R.id.btnBuscaCabelo);
        btn_busca_cabelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpService service = new HttpService("cabelo");
                try {
                    Servico servico = service.execute().get();
                }
                catch (ExecutionException e){
                    e.printStackTrace();
                }
                catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });*/
    }
    public LinkedList<Promocao> AdicionaPromocao(){
        listaPromocoes = new LinkedList<Promocao>();
        Promocao promo1 = new Promocao("Escova de Chocolate", 75.00);
        Promocao promo2 = new Promocao("Trança Espinha de Peixe", 35.00);
        Promocao promo3 = new Promocao("Hidratação e Cauterização", 93.00);
        Promocao promo4 = new Promocao("Esmaltação em Gel", 30.00);
        Promocao promo5 = new Promocao("Alongamento de Cílios Fio a Fio", 48.00);
        Promocao promo6 = new Promocao("Depilação meia perna", 15.00);
        listaPromocoes.add(promo1);
        listaPromocoes.add(promo2);
        listaPromocoes.add(promo3);
        listaPromocoes.add(promo4);
        listaPromocoes.add(promo5);
        listaPromocoes.add(promo6);
        return listaPromocoes;
    }


}
