package com.example.padroesprojetos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import com.example.padroesprojetos.Model.*;
import com.example.padroesprojetos.service.HttpService;

import java.util.List;
import java.util.concurrent.ExecutionException;


public class ControllerPromocao extends AppCompatActivity {

    private Button agendar;
    private  Button btn_busca_cabelo;

    private ArrayAdapter<String> adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promocao);
        agendar = (Button) findViewById(R.id.btn_agenda_servico);
        ListView listaPromo = (ListView)findViewById(R.id.listaPromocoes);
        Promocao promocao = new Promocao();
        List<Promocao> promocoes = promocao.ListarPromocao();
        ArrayAdapter<Promocao> adapter = new ArrayAdapter<Promocao>(this,android.R.layout.simple_list_item_1,promocoes);
        listaPromo.setAdapter(adapter);

        agendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ControllerPromocao.this, ControllerAgenda.class));
            }
        });

        btn_busca_cabelo = findViewById(R.id.btnBuscaCabelo);
        btn_busca_cabelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpService service = new HttpService("cabelo");
                try {
                    Servico servico = service.execute().get();
                }
                catch (ExecutionException e){
                    e.printStackTrace();
                }
                catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });
    }


}
