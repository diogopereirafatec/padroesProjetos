package com.example.padroesprojetos.Model;

public class Noiva {
}
