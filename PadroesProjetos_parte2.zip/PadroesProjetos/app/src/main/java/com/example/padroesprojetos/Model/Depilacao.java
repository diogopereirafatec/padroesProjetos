package com.example.padroesprojetos.Model;

public class Depilacao {
}
