package com.example.padroesprojetos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;

public class ControllerAgenda extends AppCompatActivity {

    private static final String TAG = "ControllerAgenda";
    private CalendarView mAgenda;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);
        mAgenda = findViewById(R.id.calendario);
        mAgenda.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String data = (dayOfMonth + 1) + "/" + month + "/" + year;

                Log.d(TAG,"Data Escolhida: " + data);
            }
        });


    }
}
