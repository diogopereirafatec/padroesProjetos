package com.example.padroesprojetos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

public class ControllerAgenda extends AppCompatActivity {

    private static final String TAG = "ControllerAgenda";
    private CalendarView mAgenda;
    private Button btn_voltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);
        mAgenda = findViewById(R.id.calendario);
        btn_voltar = findViewById(R.id.btnAgendamentoCLD);
        mAgenda.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String data = (dayOfMonth + 1) + "/" + month + "/" + year;

                Log.d(TAG,"Data Escolhida: " + data);
            }
        });
        btn_voltar.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            startActivity(new Intent(ControllerAgenda.this, ControllerPromocao.class));
        }
        });


    }
}
